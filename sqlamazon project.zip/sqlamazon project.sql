/*Project Objective 
The objective of this project is to analyze customer behavior, sales trends,
and product performance in the Amazon dataset to provide actionable insights for business decision-making.

Key Goals:
Product Analysis – Identify the best-performing product lines and those needing improvement.
Sales Analysis – Understand sales trends by time, payment methods, and customer segments.
Customer Analysis – Segment customers based on type, gender, and purchase frequency.
Ratings Analysis – Determine the factors influencing customer ratings, such as time of day and branch.
Branch Performance – Compare store locations based on revenue, customer engagement, and ratings.

Outcome:
This project helps businesses optimize marketing strategies, improve customer experience, and boost 
overall profitability by making data-driven decision*/
select * from projectcapstone.amazon;

#Product Analysis:
#The dataset includes six product lines (e.g., Health and Beauty, Electronic Accessories).
#Top-performing products: Based on Total sales, identify which product lines generate the highest revenue.
#Underperforming products: Compare Quantity sold and Gross income across product lines to find areas needing improvement.

SELECT 
    `Product line`,
    count("Total") AS Total_Revenue,
    count("gross income") AS Gross_Income,
    count("Quantity") AS Quantity_Sold
FROM
projectcapstone.amazon 
GROUP BY 
    `Product line`
ORDER BY 
    Total_Revenue DESC;
    
    
#Sales Analysis:
#rends over time: Use the Date and Time to identify daily, monthly, and time-of-day sales trends.
#Location performance: Analyze revenue by Branch and City to pinpoint high and low-performing regions.
#Payment methods: Examine the use of Cash, Credit card, and Ewallet to determine customer preferences.
 -- Monthly sales trend:
 SELECT 
    DATE_FORMAT(Date, '%Y-%m') AS Month, 
    Payment, 
    Branch, 
    SUM(Total) AS Total_Sales
FROM 
    projectcapstone.amazon
GROUP BY 
    Month, Payment, Branch
ORDER BY 
    Month, Total_Sales DESC;
    
    
#Customer Analysis:
-- Customer type: Compare revenue and gross income between Member and Normal customers.
-- Gender analysis: Explore how purchasing behavior varies by gender.
-- Profitability: Assess customer segments based on Gross income and Rating to identify profitable and satisfied groups.

SELECT 
    `Customer type`, 
    Gender, 
    SUM(Total) AS Total_Sales, 
    AVG(Total) AS Avg_Spending
FROM 
     projectcapstone.amazon
GROUP BY 
    `Customer type`, Gender
ORDER BY 
    Total_Sales DESC;
    
 ## To check null values:
 SELECT 
    'Invoice ID' AS Column_Name, 
    COUNT(*) AS Null_Count 
FROM 
     projectcapstone.amazon
WHERE 
    `Invoice ID` IS NULL;
    
    
 ## Add the timeofday Column 
 ALTER TABLE projectcapstone.amazon
ADD COLUMN timeofday VARCHAR(20);

# update timeofday column:
SET SQL_SAFE_UPDATES = 0;    -- turn off safe update mode, safe update mode by default 
                             -- to prevent accidental mass updates or deletions.

UPDATE projectcapstone.amazon
 SET 
 timeofday = case 
 WHEN TIME(Time) BETWEEN '00:00:00' AND '11:59:59' THEN 'Morning'
WHEN TIME(Time) BETWEEN '12:00:00' AND '16:59:59' THEN 'Afternoon'
        ELSE 'Evening'
    END;
    

## 1. Sales by Time of Day
SELECT 
    timeofday, 
    SUM(Total) AS Total_Sales
FROM 
    projectcapstone.amazon
GROUP BY 
    timeofday
ORDER BY 
    Total_Sales DESC;
    
    ## Insights:
-- Evening is likely the busiest time of the day, with the highest sales. This could be because customers shop after work or school.
-- Afternoon might have moderate sales, possibly due to lunch breaks or midday shopping.
-- Morning could have the lowest sales, as people are usually busy with work or school.  
## Recommendations:
-- Increase staff during Evening and Weekends to handle higher customer traffic. 



# Add dayname Column
ALTER TABLE projectcapstone.amazon
ADD COLUMN dayname VARCHAR(10);

UPDATE projectcapstone.amazon
SET dayname = 
    CASE DAYOFWEEK(Date)
        WHEN 1 THEN 'Sun'
        WHEN 2 THEN 'Mon'
        WHEN 3 THEN 'Tue'
        WHEN 4 THEN 'Wed'
        WHEN 5 THEN 'Thu'
        WHEN 6 THEN 'Fri'
        WHEN 7 THEN 'Sat'
    END;

-- 2. Busiest Day of the Week by Branch
SELECT 
    Branch, 
    dayname, 
    COUNT(*) AS Transaction_Count
FROM 
    projectcapstone.amazon
GROUP BY 
    Branch, dayname
ORDER BY 
    Branch, Transaction_Count DESC;
    
##Insight:
-- Weekends (Sat, Sun) are the busiest days.
-- Fridays also see increased activity.
##Recommendations:
-- Increase staff during Evening and Weekends to handle higher customer traffic.


###Add monthname Column
ALTER TABLE projectcapstone.amazon
ADD COLUMN monthname VARCHAR(10);

UPDATE projectcapstone.amazon
SET monthname = 
    CASE MONTH(Date)
        WHEN 1 THEN 'Jan'
        WHEN 2 THEN 'Feb'
        WHEN 3 THEN 'Mar'
        WHEN 4 THEN 'Apr'
        WHEN 5 THEN 'May'
        WHEN 6 THEN 'Jun'
        WHEN 7 THEN 'Jul'
        WHEN 8 THEN 'Aug'
        WHEN 9 THEN 'Sep'
        WHEN 10 THEN 'Oct'
        WHEN 11 THEN 'Nov'
        WHEN 12 THEN 'Dec'
    END;
    
    
   ### Verify the Updates
SELECT 
    Date, 
    Time, 
    timeofday, 
    dayname, 
    monthname
FROM 
     projectcapstone.amazon
LIMIT 10;


### 3. Sales and Profit by Month
SELECT 
    monthname, 
    SUM(Total) AS Total_Sales, 
    SUM(`gross income`) AS Total_Profit
FROM 
    projectcapstone.amazon
GROUP BY 
    monthname
ORDER BY 
    Total_Sales DESC; 
##Insights:
-- December is likely the month with the highest sales and profit due to holiday shopping (e.g., Christmas, New Year).
-- November might also have high sales due to events like Black Friday.
-- January and February could have lower sales as people recover from holiday spending.
-- Summer months (Jun, Jul, Aug) might see a dip in sales if customers are on vacation.
##Recommendations:
-- Offer special deals in January and February to attract customers.


###Business Questions To Answer:
-- What is the count of distinct cities in the dataset?
SELECT 
    COUNT(DISTINCT City) AS Distinct_City_Count
FROM projectcapstone.amazon;

-- This query will give you the total number of unique cities in the dataset. 
/* Insights from the Result:
The business operates in 3 cities.
We can further analyze which city has the highest sales, customer traffic, or profitability.
If the business wants to expand to new locations, this insight is useful.*/



## Q2. For each branch, what is the corresponding city?
SELECT DISTINCT Branch, City
FROM projectcapstone.amazon;

/*Insight from the Result:
This query helps map each branch to its respective city.
If the dataset contains duplicate records, they won’t be counted multiple times.
Helps in regional sales analysis, allowing the business to compare performance between branches.*/

## Q3. What is the count of distinct product lines in the dataset?
SELECT COUNT(DISTINCT `Product line`) AS distinct_product_lines
FROM projectcapstone.amazon;

/*Insights from the Result:
The dataset contains 6 unique product lines.
This helps understand the variety of products sold.
Can be used to analyze best-selling and underperforming product lines.*/

## Q4. Which payment method occurs most frequently?
SELECT Payment, COUNT(*) AS payment_count
FROM projectcapstone.amazon
GROUP BY Payment
ORDER BY payment_count DESC
LIMIT 1;

/*Insights from the Result:
The most frequently used payment method is Ewallet (example result).
Helps the business optimize checkout processes based on customer preferences.
Can be used for marketing campaigns (e.g., discounts for popular payment methods).*/


##Q5. Which product line has the highest sales?
SELECT `Product line`, count("Total") AS total_sales
FROM projectcapstone.amazon
GROUP BY `Product line`
ORDER BY total_sales DESC;

/*Insights from the Result:
The best-selling product line can help guide inventory and marketing strategies.
High sales may indicate strong customer demand for that product category.
The business can focus on promotions, bundling, or expanding this product line.*/


##Q6. How much revenue is generated each month?
SELECT 
    DATE_FORMAT(Date,'%Y-%m') AS Month,
    SUM(Total) AS total_revenue
FROM projectcapstone.amazon
GROUP BY Month
ORDER BY Month;

/*Insights from the Result:
Identifies high and low revenue months to adjust marketing and inventory.
Helps businesses forecast future sales trends.
If revenue is low in certain months, promotions can be planned to boost sales.*/


##Q7.In which month did the cost of goods sold reach its peak?
SELECT 
    DATE_FORMAT(Date,'%Y-%m') AS Month,
    SUM(cogs) AS total_cogs
FROM projectcapstone.amazon
GROUP BY Month
ORDER BY total_cogs DESC;

/*This means January 2019 had the highest COGS.
Insights from the Result:
A high COGS month could indicate high sales volume or increased purchase costs.
If profit was low despite high COGS, costs may need to be controlled.
Comparing COGS and revenue helps assess profitability trends.*/


##Q8.Which product line generated the highest revenue?
SELECT `Product line`, SUM(Total) AS total_revenue
FROM projectcapstone.amazon
GROUP BY `Product line`
ORDER BY total_revenue DESC
LIMIT 1;
-- This means "Food and Beverages" generated the highest revenue (example result).

/*Insights from the Result:
The best-performing product line indicates high customer demand.
Helps businesses focus marketing efforts on the top-selling category.
If a product line generates high revenue but low profit, pricing and cost strategies should be reviewed.*/


###Q9. In which city was the highest revenue recorded?
SELECT City, SUM(Total) AS Total_Revenue
FROM projectcapstone.amazon
GROUP BY City
ORDER BY Total_Revenue DESC
LIMIT 1;
/*Insight:
 The query identifies the city with the highest revenue from sales, which is crucial for strategic business decisions.
A city with significantly higher revenue may indicate strong demand, prompting the company to increase inventory, enhance marketing efforts, or consider expansion in that area.
Understanding revenue distribution helps analyze market trends and customer preferences, 
leading to more informed business strategies.*/



###Q10. Which product line incurred the highest Value Added Tax?
SELECT `Product line`, SUM(`Tax 5%`) AS Total_VAT
FROM projectcapstone.amazon
GROUP BY `Product line`
ORDER BY Total_VAT DESC;
/*-This query reveals which product line incurred the highest Value Added Tax, 
indicating its contribution to overall tax revenue.
-This information can help the business understand which product lines
 are more profitable and may require further analysis for pricing strategies or cost management.
- it can inform decisions regarding inventory and
 marketing focus based on the tax implications of different product lines.*/
 
 
 
 ###Q11. For each product line, add a column indicating "Good" if its sales are above average, otherwise "Bad."
  



##Q12.Identify the branch that exceeded the average number of products sold.
SELECT 
    Branch,
    SUM(Quantity) AS total_products_sold,
    CASE 
        WHEN SUM(Quantity) > (SELECT AVG(total_quantity) 
                                FROM (SELECT SUM(Quantity) AS total_quantity 
                                      FROM projectcapstone.amazon 
                                      GROUP BY Branch) AS avg_quantity) 
        THEN 'Exceeded' 
        ELSE 'Below Average' 
    END AS performance
FROM projectcapstone.amazon
GROUP BY Branch
ORDER BY total_products_sold DESC;

 /*Insights from the Result
Branches labeled "Exceeded" → Sold more than the average, indicating strong demand.
Branches labeled "Below Average" → Need improvement in sales strategies.
Helps businesses optimize inventory, marketing, and staffing based on branch performance.*/

###Q13. Which product line is most frequently associated with each gender?
SELECT Gender, `Product line`, sum(Quantity) AS purchase_count
FROM projectcapstone.amazon
GROUP BY Gender, `Product line`
HAVING purchase_count = (
    SELECT MAX(purchase_count)
    FROM (
        SELECT Gender, `Product line`, sum(Quantity) AS purchase_count
        FROM projectcapstone.amazon
        GROUP BY Gender, `Product line`
    ) AS subquery
    WHERE subquery.Gender = projectcapstone.amazon.Gender
);

/*Targeted marketing strategies → Businesses can promote the most preferred product lines by gender.
Inventory optimization → Ensure sufficient stock for high-demand products.
Helps businesses personalize offers and discounts based on gender-based preferences.*/


###Q14.Calculate the average rating for each product line.
SELECT 
    `Product line`, 
    ROUND(AVG(Rating), 2) AS avg_rating
FROM projectcapstone.amazon
GROUP BY `Product line`
ORDER BY avg_rating DESC;

/*Insights from the Result
Higher-rated products → Customers like these products and may recommend them.
Lower-rated products → May require quality improvements or better marketing strategies.
Helps businesses focus on customer satisfaction and prioritize top-rated product lines.*/



###Q15.Count the sales occurrences for each time of day on every weekday.
SELECT 
    dayname AS weekday,
    timeofday,
    COUNT(*) AS sales_count
FROM projectcapstone.amazon
GROUP BY dayname, timeofday
ORDER BY dayname,timeofday;

/*Insights from the Result
Helps determine peak business hours for each day.
Useful for staffing, promotions, and optimizing store hours.
If weekends have higher sales, businesses can extend working hours or run promotions.*/



###Q16.Identify the customer type contributing the highest revenue.
SELECT 
    `Customer type`,
    SUM(Total) AS TotalRevenue
FROM 
   projectcapstone.amazon
GROUP BY 
    `Customer type`
ORDER BY 
    TotalRevenue DESC
LIMIT 1;

/*Insight:
The result shows which customer type is contributing the most revenue,
 which can help businesses focus their marketing and retention strategies on that customer type.*/
 
 
 ###Q17.Determine the city with the highest VAT percentage.
 SELECT 
    City,
    (SUM(`Tax 5%`) / SUM(Total)) * 100 AS VATPercentage
FROM 
   projectcapstone.amazon
GROUP BY 
    City
ORDER BY 
    VATPercentage DESC;
    
/*Insight:
The result shows which city has the highest VAT percentage, 
which can help businesses understand the tax implications in different regions.*/


###Q18.Identify the customer type with the highest VAT payments.
SELECT 
    `Customer type`, 
    count("Tax 5%") AS total_vat_paid
FROM projectcapstone.amazon
GROUP BY `Customer type`
ORDER BY total_vat_paid DESC
LIMIT 1;

/*Insights from the Result
High VAT payments indicate higher spending by a specific customer type.
If Members pay more VAT, they might purchase higher-priced items or larger quantities.
Businesses can analyze pricing strategies and offer VAT-related discounts or benefits to boost loyalty.*/



###Q19.What is the count of distinct customer types in the dataset?
SELECT COUNT(DISTINCT `Customer type`) AS distinct_customer_types
FROM projectcapstone.amazon;
/*Insights from the Result
Helps understand customer segmentation in the business.
If the dataset has only Members and Normal customers, businesses can analyze their spending behavior separately.
If more customer types exist, further analysis can be done on their purchase trends and profitability.*/



###Q20.What is the count of distinct payment methods in the dataset?
SELECT COUNT(DISTINCT Payment) AS distinct_payment_methods
FROM projectcapstone.amazon;

/*Insights from the Result
Helps identify the most commonly used payment options by customers.
Businesses can optimize checkout processes based on preferred payment methods.
If digital payments dominate, companies can offer discounts for e-wallet transactions to encourage faster payments.*/



###Q21.Which customer type occurs most frequently?
SELECT `Customer type`, COUNT(*) AS customer_count
FROM projectcapstone.amazon
GROUP BY `Customertype`
ORDER BY customer_count DESC
LIMIT 1;
 /*Insights from the Result
If Members are more frequent, businesses can focus on loyalty programs and exclusive offers.
If Normal customers dominate, strategies to convert them into Members (through discounts or perks) should be considered.
Helps businesses understand customer segmentation and optimize marketing strategies accordingly.*/


###Q22.Identify the customer type with the highest purchase frequency.
SELECT `Customer type`, COUNT(`Invoice ID`) AS purchase_frequency
FROM projectcapstone.amazon
GROUP BY `Customer type`
ORDER BY purchase_frequency DESC
LIMIT 1;

/*Insights from the Result
If Members purchase more frequently, businesses can offer exclusive rewards to retain them.
If Normal customers have a high purchase frequency, the business can introduce membership programs to increase loyalty.
Helps optimize promotions and marketing strategies based on customer behavior.*/



###Q23.Determine the predominant gender among customers.
SELECT Gender, COUNT(*) AS gender_count
FROM projectcapstone.amazon
GROUP BY Gender
ORDER BY gender_count DESC
LIMIT 1;

/*Insights from the Result
If Females dominate, businesses can tailor promotions, product offerings, and marketing strategies to attract and retain female customers.
If Males and Females are nearly equal, a balanced marketing strategy should be adopted.
Helps in understanding customer demographics and segmenting target audiences effectively.*/



###Q24.Examine the distribution of genders within each branch.
SELECT 
    Branch, 
    Gender, 
    COUNT(*) AS gender_count
FROM projectcapstone.amazon
GROUP BY Branch, Gender
ORDER BY Branch, gender_count DESC;

/*Insights from the Result
Helps in understanding gender-based preferences per branch.
If one gender dominates a branch, businesses can tailor marketing campaigns accordingly.
Useful for staffing decisions, product placements, and personalized promotions.*/



###Q25.Identify the time of day when customers provide the most ratings.
SELECT 
    timeofday, 
    COUNT(Rating) AS rating_count
FROM projectcapstone.amazon
GROUP BY timeofday
ORDER BY rating_count DESC
LIMIT 1;

/*Insights from the Result
If Afternoon has the highest ratings, businesses may focus customer engagement strategies (e.g., follow-up messages or review prompts) during this time.
Helps in timing customer feedback surveys for maximum response.
If Evening or Morning shows low ratings, businesses can encourage customers to leave reviews during those periods.*/


###Q26.Determine the time of day with the highest customer ratings for each branch.
SELECT 
    Branch, 
    timeofday, 
    ROUND(AVG(Rating), 2) AS avg_rating
FROM projectcapstone.amazon
GROUP BY Branch, timeofday
ORDER BY Branch, avg_rating DESC;

/*Insights from the Result
Helps determine the best service times for each branch.
If one branch has consistently lower ratings at a specific time, businesses can investigate possible issues (e.g., staff shortages, peak-hour delays).
Can be used to optimize marketing campaigns, promotions, and service quality improvements.*/



###Q27.Identify the day of the week with the highest average ratings.
SELECT 
    dayname AS weekday, 
    ROUND(AVG(Rating), 2) AS avg_rating
FROM projectcapstone.amazon
GROUP BY dayname
ORDER BY avg_rating DESC
LIMIT 1;

/* Insights from the Result
=Peak customer satisfaction on certain days can indicate better service or product availability.
=If weekends have the highest ratings, businesses can focus on 
promotional activities and customer engagement during those days.
=If certain weekdays have lower ratings, businesses can investigate
 possible reasons (e.g., fewer staff, lower traffic, inventory issues).*/
 
 
 
 
 ###Q28.Determine the day of the week with the highest average ratings for each branch.
SELECT 
    Branch, 
    dayname AS weekday, 
    ROUND(AVG(Rating), 2) AS avg_rating
FROM projectcapstone.amazon
GROUP BY Branch, dayname
ORDER BY Branch, avg_rating DESC;

/*Insights from the Result
Helps businesses understand when customer satisfaction is highest for each branch.
If a branch has low ratings on specific days, managers can investigate and improve service.
Useful for planning staffing, promotions, and customer engagement strategies based on peak rating days.*/
































